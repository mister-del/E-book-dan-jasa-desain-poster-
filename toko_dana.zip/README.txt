CARA PAKAI
1. Buka index.html di browser.
2. Edit bagian const DANA_LINK di dalam index.html.
3. Ganti data produk pada const products (nama, harga, foto, deskripsi).
4. Untuk foto produk, masukkan URL gambar pada properti image.
5. Upload index.html ke hosting website.

CATATAN
Versi ini memakai pembayaran manual: pembeli checkout lalu diarahkan ke link pembayaran DANA.
Jangan meminta PIN/OTP DANA di website.
Untuk pembayaran otomatis + verifikasi status pembayaran, nanti perlu payment gateway/API.
